class Landing < ApplicationRecord
end
