require 'test_helper'

class LandingTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
