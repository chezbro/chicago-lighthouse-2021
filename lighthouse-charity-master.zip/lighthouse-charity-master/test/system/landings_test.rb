require "application_system_test_case"

class LandingsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit landings_url
  #
  #   assert_selector "h1", text: "Landing"
  # end
end
